package com.potentborn.kportscan;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class PortHelper {

    public static boolean isTcpPortOpen(InetAddress address, int port, int timeoutMillis) {
        try (Socket socket = new Socket()) {
            SocketAddress sockaddr = new InetSocketAddress(address, port);
            socket.connect(sockaddr, timeoutMillis); // Устанавливаем таймаут
            return true;
        } catch (SocketTimeoutException e) {
            // Таймаут истек - порт закрыт или недоступен
            return false;
        } catch (IOException e) {
            // Другая ошибка - порт закрыт или недоступен
            return false;
        }
    }

    public static boolean isUdpPortOpen(InetAddress address, int port, int timeoutMillis) {
        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setSoTimeout(timeoutMillis); // Устанавливаем таймаут

            byte[] buffer = new byte[1]; // Отправляем пустой пакет
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length, address, port);
            socket.send(packet);

            // Пытаемся получить ответ (вероятность успеха мала, если порт закрыт)
            byte[] receiveBuffer = new byte[1024]; // достаточно для ответа
            DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
            socket.receive(receivePacket); // Таймаут сработает если порт закрыт
            return true;
        } catch (SocketTimeoutException e) {
            // Таймаут истек - порт закрыт или недоступен
            return false;
        } catch (SocketException e) {
            return false;
        } catch (IOException e) {
            return false;
        }
    }
}
