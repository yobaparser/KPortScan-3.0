package com.potentborn.kportscan;

import android.app.Activity;
import android.view.WindowManager;

public class Screenshot {

    public static void Enable(Activity activity)
    {
        WindowManager.LayoutParams params = activity.getWindow().getAttributes();
        params.flags |= WindowManager.LayoutParams.FLAG_SECURE;
        activity.getWindow().setAttributes(params);
    }

    public static void Disable(Activity activity)
    {
        WindowManager.LayoutParams params = activity.getWindow().getAttributes();
        params.flags &= ~WindowManager.LayoutParams.FLAG_SECURE;
        activity.getWindow().setAttributes(params);
    }
}