package com.potentborn.kportscan;

import android.content.Context;
import android.widget.Toast;

public class ToastHelper {
    public static void showLocalizedToast(Context context, int messageResId)
    {
        String message = context.getString(messageResId);
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
}
