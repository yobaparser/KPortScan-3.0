package com.potentborn.kportscan;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.SyncStateContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** @noinspection ALL*/
public class MainActivity extends AppCompatActivity {
    private EditText editTextIpRanges;
    private EditText editTextPort;
    private EditText editTextThread;

    private Button buttonScan;
    private TextView resultsTextView;
    private ScrollView scrollView;

    private ProgressBar progressBarPart1;
    private ProgressBar progressBarPart2;

    private Switch mySwitch;

    private  boolean bToggleSwitch = true;
    private boolean bStop = false;

    ScanTask scanTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        editTextIpRanges = findViewById(R.id.editRanges);
        editTextPort = findViewById(R.id.editPort);

        editTextThread = findViewById(R.id.editThread);
        buttonScan = findViewById(R.id.buttonScan);

        progressBarPart1 = findViewById(R.id.progressBarPart1);
        progressBarPart2 = findViewById(R.id.progressBarPart2);

        resultsTextView = findViewById(R.id.resultsTextView);

        scrollView = findViewById(R.id.scrollView);
        mySwitch = findViewById(R.id.mySwitch);

        ImageView gifImageView = findViewById(R.id.imageView);

        Glide.with(MainActivity.this)
                .asGif()
                .load(R.drawable.logo)
                .into(gifImageView);

        buttonScan.setBackgroundColor(getResources().getColor(R.color.violet));
        scrollView.setSmoothScrollingEnabled(true);

        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (bToggleSwitch)
                {
                    ToastHelper.showLocalizedToast(MainActivity.this, R.string.udp);
                }
                else
                {
                    ToastHelper.showLocalizedToast(MainActivity.this, R.string.tcp);
                }

                bToggleSwitch = !bToggleSwitch;
            }
        });

        buttonScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isNetworkConnected())
                {
                    ToastHelper.showLocalizedToast(MainActivity.this, R.string.disconnect);
                    return;
                }

                int port = 0;
                int speed = 0;

                String ipRange = editTextIpRanges.getText().toString().trim();

                try
                {
                    port = Integer.parseInt(editTextPort.getText().toString().trim());
                    speed = Integer.parseInt(editTextThread.getText().toString().trim());
                }
                catch (NumberFormatException e)
                {
                    return;
                }

                if (port <= 0 || port >= 65536)
                {
                    return;
                }

                if (speed <= 0 || speed >= 2001)
                {
                    return;
                }

                if (ipRange.isEmpty())
                {
                    return;
                }

                if(!ipRange.contains("-") || ipRange.contains(" "))
                {
                    return;
                }

                if (bStop)
                {
                    buttonScan.setText(R.string.scan);
                    scanTask = null;
                    bStop = false;
                }
                else
                {
                    buttonScan.setText(R.string.stop);
                    scanTask = (ScanTask) new ScanTask(ipRange, port, speed, progressBarPart1, progressBarPart2, resultsTextView).execute();
                    bStop = true;
                }
            }
        });
    }

    private boolean isNetworkConnected()
    {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = cm.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    /** @noinspection deprecation*/
    public class ScanTask extends AsyncTask<Void, String, List<String>> {
        private String ipRange;
        private int port;
        private int speed;

        private ProgressBar progressBarPart1;
        private ProgressBar progressBarPart2;

        private final TextView resultsTextView;
        private Handler handler;

        public ScanTask(String ipRange, int port, int speed, ProgressBar progressBarPart1, ProgressBar progressBarPart2, TextView resultsTextView) {
            this.ipRange = ipRange;
            this.port = port;
            this.speed = speed;
            this.progressBarPart1 = progressBarPart1;
            this.progressBarPart2 = progressBarPart2;
            this.resultsTextView = resultsTextView;
            this.handler = new Handler(Looper.getMainLooper());
        }

        @Override
        protected void onPreExecute()
        {
            handler.post(() -> {
                progressBarPart1.setVisibility(ProgressBar.VISIBLE);
                progressBarPart2.setVisibility(ProgressBar.VISIBLE);
            });

            resultsTextView.setText(R.string.start_scan);
        }

        @Override
        protected List<String> doInBackground(Void[] voids) {
            List<String> results = new ArrayList<>();
            List<String> ipRanges = parseIpRanges(ipRange);
            long totalAddresses = 0;

            try {
                for (String ipRange : ipRanges) {

                    String[] ipParts = ipRange.split("-");
                    String startIP = ipParts[0];
                    String endIP = ipParts[1];

                    String[] startIPParts = startIP.split("\\.");
                    String[] endIPParts = endIP.split("\\.");

                    int startOctet3 = Integer.parseInt(startIPParts[2]);
                    int endOctet3 = Integer.parseInt(endIPParts[2]);

                    int startOctet4 = Integer.parseInt(startIPParts[3]);
                    int endOctet4 = Integer.parseInt(endIPParts[3]);

                    totalAddresses = (long) (endOctet3 - startOctet3 + 1) * (endOctet4 - startOctet4 + 1);

                    long currentAddress = 0;

                    for (int i = startOctet3; i <= endOctet3; i++) {
                        if (!bStop) {
                            return results;
                        }

                        for (int j = startOctet4; j <= endOctet4; j++) {
                            if (!bStop) {
                                return results;
                            }

                            String ipAddress = startIPParts[0] + "." + startIPParts[1] + "." + i + "." + j;

                            currentAddress++;
                            int part1 = (int) ((currentAddress * 100) / totalAddresses);
                            progressBarPart1.setProgress(part1);

                            int part2 = (int) (((double) (j - Integer.parseInt(startIPParts[3]) + 1) / (Integer.parseInt(endIPParts[3]) - Integer.parseInt(startIPParts[3]) + 1)) * 100);
                            progressBarPart2.setProgress(part2);

                            if(bToggleSwitch)
                            {
                                if (PortHelper.isTcpPortOpen(InetAddress.getByName(ipAddress), port, speed)) {
                                    results.add(ipAddress);
                                    publishProgress(ipAddress);
                                }
                            }
                            else
                            {
                                if (PortHelper.isUdpPortOpen(InetAddress.getByName(ipAddress), port, speed)) {
                                    results.add(ipAddress);
                                    publishProgress(ipAddress);
                                }
                            }
                        }
                    }
                }
            } catch (IOException e) {
                Log.e("ScanTask", "Error Message: " + e);
            } finally
            {
                progressBarPart1.setProgress(0);
                progressBarPart2.setProgress(0);
            }

            return results;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            handler.post(() ->
            {
                resultsTextView.append("\n" + values[0]);

                progressBarPart1.setVisibility(ProgressBar.VISIBLE);
                progressBarPart2.setVisibility(ProgressBar.VISIBLE);
            });
        }

        @Override
        protected void onPostExecute(List<String> results)
        {
            handler.post(() ->
            {
                if (results.isEmpty())
                {
                    resultsTextView.setText(R.string.no_open_ports_found);
                }
                else
                {
                    StringBuilder sb = new StringBuilder();

                    for (String result : results)
                    {
                        sb.append(result).append("\n");
                    }

                    resultsTextView.setText(sb.toString());
                    copyTextToClipboard();
                }

                progressBarPart1.setVisibility(ProgressBar.GONE);
                progressBarPart2.setVisibility(ProgressBar.GONE);
            });
        }
    }

    public void copyTextToClipboard()
    {
        String textToCopy = resultsTextView.getText().toString();

        if (textToCopy.isEmpty())
        {
            return;
        }
        else
        {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText(null, textToCopy);
            clipboard.setPrimaryClip(clip);
            ToastHelper.showLocalizedToast(MainActivity.this, R.string.save);
        }
    }

    private List<String> parseIpRanges(String ipRangesStr)
    {
        List<String> ranges = new ArrayList<>();
        String[] lines = ipRangesStr.split("\n");

        for (String line : lines)
        {
            line = line.trim();

            if (!line.isEmpty())
            {
                Pattern pattern = Pattern.compile("(\\d+\\.\\d+\\.\\d+\\.\\d+)-(\\d+\\.\\d+\\.\\d+\\.\\d+)");
                Matcher matcher = pattern.matcher(line);

                if (matcher.find())
                {
                    ranges.add(matcher.group(1) + "-" + matcher.group(2));
                }
            }
        }

        return ranges;
    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
    }
}